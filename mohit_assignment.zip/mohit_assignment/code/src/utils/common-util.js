// place common util functions here
const defaulFormate = "en-US";

// added date format internationalization
const dateFormater = function(date) {
    let dateFormat = new Date(date);
    return new Intl.DateTimeFormat(defaulFormate, {
        dateStyle: "full"
    }).format(
        dateFormat
    );
};