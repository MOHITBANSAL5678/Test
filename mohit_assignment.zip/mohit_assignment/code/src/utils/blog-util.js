//helper util for blog page

// crete Dom for blogs (right side view)
createBlogDom = (records = []) => {
    let data = records.map((record) => {
        return `<section >
  <div class="container-box">
  <h4>${record?.title || "No Title Found"}</h4>
  <p>${record?.timestamp? dateFormater(record?.timestamp) : "" }</p>
  <article>
    <p>${record?.text || "No Text Found"}</p>
  </article>
  <button type="button" id="${record?.id}" class="btn btn-info edit-record">Edit</button>
  <button type="button" class="btn btn-danger delete-record" id="${record?.id}">Delete</button>
</div>
</section>`;
    });
    return data.join("");
};


// crete Dom for blogs dates list (left side view)
createBlogDatesDom = (records = []) => {
    let data = records.map((record) => {
        return ` <div class="blogs-date col-md-12"> <span>${record?.timestamp? dateFormater(record?.timestamp) : "" }<span> -  ${record?.id || "No Id Found"}</div>`;
    });
    return data.join("");
};

// sort blogs in descending order
sortBlogs = (blogs) => {
    return blogs.sort((a, b) => b.id - a.id)

}