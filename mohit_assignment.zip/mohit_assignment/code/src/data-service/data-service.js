const url = "https://salesforce-blogs.herokuapp.com/blogs/api/";

// data service to get,post,put apis

class DataService {

    //get api
    get() {
        const fetchPromise = fetch(url);
        return fetchPromise
            .then((response) => response.json())
            .catch((error) => alert(error));
    }

    // post api
    post(data) {

        return fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', },
                body: JSON.stringify(data)
            })
            .then(res => res.json())
            .catch((error) => alert(error))
    }

    // post api with id (use for patch/put update) 
    put(id, data) {
        return fetch(url + id, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', },
                body: JSON.stringify(data)
            })
            .then(res => res.json())
            .catch((error) => alert(error))
    }

    // delete by id api
    delete(id) {
        return fetch(url + id, { method: 'DELETE' })
            .then(res => res.json())
            .catch((error) => alert(error))
    }

    // delete all api
    deleteAll() {
        return fetch(url, { method: 'DELETE' })
            .then(res => res.json())
            .catch((error) => alert(error))
    }


}

// Singleton instance for data service
const dataService = new DataService();
Object.freeze(dataService);
//    default dataService;