// page constants
const EDIT = "Edit Blog"

class Blog {
    constructor() {
        // store list of blogs
        this.data = [];

        // dom elements of blogs(right view) and blogs date list(left view)
        this.blogs = document.getElementById("blogs");
        this.blogDates = document.getElementById("blogs-dates");

        /**
         *   dom elements of create/edit button inside modal (save button inside modal window)
         *   binding event listeners on click save button inside modal window for create/edit blog
         */
        this.createRecord = document.getElementById("create-record");
        this.createRecord.addEventListener("click", this.onSaveModal(this));

        /**
         * dom elements of create button (left view top)
         * open modal window afte click this
         * on click updating title as 'Create Blog' and clear edit field b/c this use for create blog modal window
         */
        this.createModal = document.getElementById("create-modal");
        this.createModal.addEventListener("click", function() {
            document.getElementById("modal-title").innerHTML = "Create Blog"
            document.getElementById("blog-edit-id").value = null;
        });

        /**
         * dom elements of delete button (left view top)
         * on click delete all, call delete all api
         */
        this.deleteAllEl = document.getElementById("delete-all");
        this.deleteAllEl.addEventListener("click", this.deleteAll());
    }

    // fetch data from get api call and set all blogs to data variable.
    fetchData() {
        dataService
            .get()
            .then((blogs) => {
                this.data = blogs
                this.loadDom();
            })
            // handelling error 
            .catch((error) => console.log('Check the response,it is returing an error' + error));
    }

    // load dom html for blogs(right view) and blogs date list(left view)
    loadDom() {
        this.data = sortBlogs(this.data);
        this.blogs.innerHTML = createBlogDom(this.data);
        this.blogDates.innerHTML = createBlogDatesDom(this.data);
        this.resisterEvents()
    }

    /**
     * binding event listeners on click for edit and delete button.
     * this run after dom updation for blogs list.
     * binding event listener for edit and delete button
     */
    resisterEvents() {
        this.blogEdit = document.getElementsByClassName("edit-record");
        this.blogDelete = document.getElementsByClassName("delete-record");
        Object.keys(this.blogDelete).forEach(button => {
            this.blogDelete[button].addEventListener("click", this.delete(this));
        });
        Object.keys(this.blogEdit).forEach(button => {
            this.blogEdit[button].addEventListener("click", this.onEditClick(this));
        });
    }

    /**
     * on click edit button, opening modal window
     * set input field title, id and text from selected blog
     * set modal title as 'Edit Blog' b/c this use for edit blog modal window
     */
    onEditClick(_self) {
        let self = _self;
        return (e) => {
            let myModal = new bootstrap.Modal(document.getElementById('myModal'), {})
            myModal.toggle()
            let blog = this.data.find(d => d.id === Number(e.target.id))
            document.getElementById("blog-title").value = blog.title;
            document.getElementById("blog-text").value = blog.text;
            document.getElementById("blog-edit-id").value = blog.id;
            document.getElementById("modal-title").innerHTML = EDIT;
        };
    }

    /**
     * trigger after click on save button inside modal window
     * check blog type from 'edit' or 'newly created'
     * call update methode for edit mode or call create methode for new blog
     */
    onSaveModal(_self) {
        let self = _self;
        return (event) => {
            event.stopPropagation();
            let title = document.getElementById("blog-title").value;
            let text = document.getElementById("blog-text").value;
            let id = document.getElementById("blog-edit-id").value;
            id ? this.update(id, {
                'title': title,
                'text': text
            }) : this.create({
                'title': title,
                'text': text
            })
        };
    }

    // update existing blog and update blog list
    update(id, data) {
        dataService
            .put(id, data)
            .then((blog) => {
                this.data = this.data.filter(d => d.id !== blog.id)
                this.data.push(blog)
                this.loadDom()
            })
            // handelling error 
            .catch((error) => console.log('Check the response,it is returing an error' + error));
    }


    // create new blog and update blog list
    create(data) {
        dataService
            .post(data)
            .then((blog) => {
                this.data.push(blog)
                this.loadDom()
            })
            // handelling error 
            .catch((error) => console.log('Check the response,it is returing an error' + error));
    }

    // delete selected blog and update blog list
    delete(_self) {
        let self = _self;
        return (e) => {
            dataService
                .delete(e.target.id)
                .then((msg) => {
                    this.fetchData();
                })
                // handelling error 
                .catch((error) => console.log('Check the response,it is returing an error' + error));
        };
    }

    // delete all blog and update blog list
    deleteAll() {
        return (e) => {
            dataService
                .deleteAll()
                .then((msg) => {
                    this.fetchData();
                })
                // handelling error 
                .catch((error) => console.log('Check the response,it is returing an error' + error));
        };
    }

}

var page = new Blog();
page.fetchData();