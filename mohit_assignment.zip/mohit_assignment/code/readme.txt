# Author 
Mohit Bansal | mohitbansal5678@gmail.com

# Project Start
Directly open Index.html into browser (I developed this using google chrome browser)

# Project Start
Directly open Index.html into browser (I developed this using google chrome browser)

# Test flow 
 1. Onload list of blogs are coming on right side and list of dates are coming on left side
 2. Working operation of Edit,Delete,Deleted All,Create blogs.


# Libraries  used
Added bootstrap 4 through cdn path and application modal window is used from bootstrap 4

